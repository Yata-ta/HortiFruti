# HortiFruti
Automation and control of cold rooms for implementation in Brazil
