import os
import psycopg2


try:

    print('AQUI')

    #DATABASE_URL = os.environ['postgres://kxxubuuaqoiacg:baee797511a5a5a24c7124d3495a82ce9fc4ac0ff874d1181d909f0b7e2adf4a@ec2-54-75-26-218.eu-west-1.compute.amazonaws.com:5432/d5s6ue6qinl0ng']

    DATABASE_URL = 'postgres://kxxubuuaqoiacg:baee797511a5a5a24c7124d3495a82ce9fc4ac0ff874d1181d909f0b7e2adf4a@ec2-54-75-26-218.eu-west-1.compute.amazonaws.com:5432/d5s6ue6qinl0ng'

    print(DATABASE_URL)

    print('AQUI2')

    conn = psycopg2.connect(DATABASE_URL, sslmode='require')

    # create a cursor
    cur = conn.cursor()

    # define query
    query = 'Select * from up201801019.sensor where contentorid=' + str(1)

    cur.execute(query)

    rec = cur.fetchall()

    if rec == None:
        print('Here')
        if conn is not None:
            conn.close()

    # Close db connection
    if conn is not None:
        print(rec)
        conn.close()
    # print('Database connection closed.')

except (Exception, psycopg2.DatabaseError) as error:
    print(error)
